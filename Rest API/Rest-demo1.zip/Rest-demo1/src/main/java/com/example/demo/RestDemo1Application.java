package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController                                                     // RestController = ResponceBody + Controller
public class RestDemo1Application {

	@GetMapping("/main")                                            // it is not nice to use here create Mycontroller.java class define mappings & method
    @ResponseBody                                                   // if you do not use @ResponseBody no prblm because above we used @RestController which inludes @ResponseBody
	public String home() {
		
		return "This is my first rest controller in Main Class";   // @ResponseBody or @ResController -- for returning body,content(message) not url(webpages ex: .jsp,.html)
	}                                                              
	
	public static void main(String[] args) {
		SpringApplication.run(RestDemo1Application.class, args);
		System.out.println("Hello Hitman");
		System.out.println("Good morning");

	}

}


// When we use @ResController or @ResponseBody -- output will display as message(converted to JSON (text type) to display on browser instead of in console
/* When we use
             @Controller     -- must use @ResponseBody (for returning message instead of url)
             
             @RestController --  no need  to use (dy default behave as @ResponseBody )
                                 combination of (@ResponceBody + @Controller)
*/

/* For OUTPUT:            use URL                          Output in browser
           
                      localhost:8080/maina        -->   "This is my first rest controller in Main Class"
                      localhost:8080/controller   -->    "My Controller REST"
*/