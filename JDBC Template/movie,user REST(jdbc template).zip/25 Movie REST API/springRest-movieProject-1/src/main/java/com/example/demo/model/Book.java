package com.example.demo.model;
import java.util.Date;

public class Book {
	private Long id;
	private Date bookDate;
	private Long theatreId;
	private Long movieId;
	private Long customerId;
	private Long tickets;
	
	public Book()
	{
		
	}
	public Book(Long id, Date bookDate, Long theatreId, Long movieId, Long customerId, Long tickets) {
		super();
		this.id = id;
		this.bookDate = bookDate;
		this.theatreId = theatreId;
		this.movieId = movieId;
		this.customerId = customerId;
		this.tickets = tickets;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getBookDate() {
		return bookDate;
	}
	public void setBookDate(Date bookDate) {
		this.bookDate = bookDate;
	}
	public Long getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(Long theatreId) {
		this.theatreId = theatreId;
	}
	public Long getMovieId() {
		return movieId;
	}
	public void setMovieId(Long movieId) {
		this.movieId = movieId;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Long getTickets() {
		return tickets;
	}
	public void setTickets(Long tickets) {
		this.tickets = tickets;
	}

	
	
}
