package com.example.demo.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;


public class Movie {
	
	private Long movieId;
	private String movieName;
//	private Date releaseDate;
//  private List theatreList;
	private Long theatreId;
	public Movie() {
		//theatreList = new ArrayList();
	}
	
	public Movie(Long movieId, String movieName, Long theatreId) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
	//	this.theatreList = theatreList;
		this.theatreId = theatreId;
	}
	
	public Long getMovieId() {
		return movieId;
	}

	public void setMovieId(Long movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public Long getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(Long theatreId) {
		this.theatreId = theatreId;
	}

//	public List getTheatreList() {
//		return theatreList;
//	}
//
//	public void setTheatreList(List theatreList) {
//		this.theatreList = theatreList;
//	}
	

	
}
