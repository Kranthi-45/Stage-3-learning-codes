package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.Movie;
import com.example.demo.model.Theatre;

public interface MovieDAO {

    public String QUERY_CREATE_NEW_MOVIE="INSERT INTO movie(movieId,movieName,theatreId) VALUES (?,?,?)";
    public String QUERY_GET_MOVIES_OF_THEATRE="SELECT  mov.movieId AS `movieId`,   mov.movieName AS `movieName`,  th.theatreId AS `theatreId`"
    		+ "                   			  FROM  theatre th  INNER JOIN movie mov"
    		+ "                               ON th.theatreId = mov.theatreId WHERE  th.theatreId = ?";
    public String QUERY_DELETE_MOVIE_BY_ID ="DELETE FROM movie WHERE movieId= ?";
    public String QUERY_GET_MOVIE_BY_ID ="SELECT mov.movieId AS `movieId`, mov.movieName AS `movieName`, mov.theatreId AS `theatreId`"
    		+ "                           FROM movie mov WHERE mov.movieId = ?";
    public String QUERY_GET_All_MOVIES ="SELECT * FROM movie";
    public String QUERY_MODIFY_MOVIE_ID ="UPDATE movie SET movieName=?, theatreId=? WHERE movieId=?";
    public String QUERY_GET_ALL_THEATRES_BY_MOVIE ="";
    
    		
    public List<Movie> getMoviesOfTheatre(Theatre theatre);  
    public boolean createNewMovie(Movie mov);
    public boolean deleteMovieById(Long id);
    public Movie getMovieById(Long id);
    public List<Movie> getAllMovies();
    public int modifyMovie(Movie movie);
    public List<Movie> getAllTheatresByMovie(Long id); 

}

/*
 * public String
 * QUERY_GET_MOVIES_OF_THEATRE="SELECT  mov.movieId AS `movieId`,   mov.movieName AS `movieName`,  thm.Theatre_theatreId AS `theatreId`"
 * +
 * "                   			  FROM  theatre_has_movie thm  INNER JOIN movie mov"
 * +
 * "                               ON thm.Movie_movieId = mov.movieId WHERE  thm.Theatre_theatreId = ?"
 * ;
 */