export class Branch {
                                                                                      
    bid:string='1919';                                     // 4th => create branch class   
    bname:string='sravu';                                  // 5th => create branch object in typescript (branch.component.ts) and intilize varibles
    bcity:string='Araku';
}
