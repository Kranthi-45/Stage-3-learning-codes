import { Component, OnInit } from '@angular/core';
import { Branch } from '../branch';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.css']
})
export class BranchComponent implements OnInit {

  bid:string="1676" ;                                                  //Property Binding : linking this variables of (branch.ts) with (branch.html) for dynamic initialization of variables
  bname:string="Kranthi's branch";
  bcity:string="Hyderbad";

  constructor() { }

  ngOnInit(): void {
  }

  fnAdd(){                                                              // Event Binding : fnAdd() function in .ts file is bound to the click event button in html
    alert("Hello World");
    alert(this.bid + " : " + this.bname + " : " + this.bcity);

    var branch:Branch= new Branch();
    branch.bid=this.bid;
    branch.bname=this.bname;
    branch.bcity=this.bcity; 
    console.log(branch);                                               // 6th => Run the program, console.log() will displays o/p in browser by clicking inspect
 // alert(branch)                                                      // 7Th => display Branch Object in alert : but objects are not displayed in alert, convert to json for displaying those
                                                                                    
    alert(JSON.stringify(branch))                                      // OBJECT to JSON :  JSON.stringify(branch) , JSON to OBJECT : JSON.parse(json)
   }

}
