import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Theatre } from '../theatre';
import { TheatreService } from '../theatre.service';

@Component({
  selector: 'app-theatre',
  templateUrl: './theatre.component.html',
  styleUrls: ['./theatre.component.css']
})
export class TheatreComponent implements OnInit {

 
  adminTheatreForm:any;
  theatres:any;
   constructor(private fb: FormBuilder, private ts: TheatreService) { 
     this.adminTheatreForm=this.fb.group({
       theatreId:[''],
       theatreName:['']
     });
   }
  ngOnInit(): void {
    this.ts.getAllTheatre().subscribe((data)=>{
      console.log(data);
      this.theatres=data;                                  
     })

  }
 
  fnAdd(){
   
    var theatre = new Theatre();

    theatre.theatreId=this.adminTheatreForm.controls['theatreId'].value;
    theatre.theatreName=this.adminTheatreForm.controls['theatreName'].value;

    alert("add theatre id & name " +JSON.stringify(theatre));
    this.ts.addTheatre(theatre).subscribe(data=>console.log(data));
  }
  fnModify(){

    var theatre = new Theatre();
    theatre.theatreId=this.adminTheatreForm.controls['theatreId'].value;
    theatre.theatreName=this.adminTheatreForm.controls['theatreName'].value;

    alert("modify theatre id & name " +JSON.stringify(theatre));
    this.ts.modifyTheatre(theatre).subscribe(data=>console.log(data));
  }

  fnDelete(){

    var theatre = new Theatre();
    theatre.theatreId=this.adminTheatreForm.controls['theatreId'].value;
    theatre.theatreName=this.adminTheatreForm.controls['theatreName'].value;

    alert("remove theatre id & name " +JSON.stringify(theatre));
    this.ts.removeTheatre(theatre.theatreId).subscribe(data=>console.log(data));

  }
}
