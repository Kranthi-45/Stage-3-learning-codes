
export class Movie {
    movieId:number | undefined;
    movieName:string | undefined;
    theatreId:number| undefined;
}
