import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Movie } from '../movie';
import { MovieService } from '../movie.service';
import { Theatre } from '../theatre';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {


  adminMovieForm:any;
   movies:any;
   constructor(private fb: FormBuilder, private ms: MovieService ) { 
     this.adminMovieForm=this.fb.group({
       movieId:[''],
       movieName:[''],
       theatreId:['']
   /*     picture:[''] */
     });
   }
  ngOnInit(): void {
    this.ms.getAllMovie().subscribe((data)=>{
      console.log(data);
      this.movies=data;                                  
     })
  }

  fnAdd(){
   
    var movie=new Movie();
    //var theatre = new Theatre();

    movie.movieId=this.adminMovieForm.controls['movieId'].value;
    movie.movieName=this.adminMovieForm.controls['movieName'].value;
    movie.theatreId=this.adminMovieForm.controls['theatreId'].value;

    
   //alert("fn ADD " +JSON.stringify(movie));

   // theatre.id=this.adminMovieForm.controls['theatre'].value;
   // alert("theatre id " +JSON.stringify(theatre));
   // movie.theatre=theatre;
    

    alert("fn ADD " +JSON.stringify(movie));

    this.ms.addMovie(movie).subscribe(data=>console.log(data));
  }

  fnModify(){

    var movie=new Movie();
   // var theatre = new Theatre();

    movie.movieId=this.adminMovieForm.controls['movieId'].value;
    movie.movieName=this.adminMovieForm.controls['movieName'].value;
    movie.theatreId=this.adminMovieForm.controls['theatreId'].value;;
    //theatre.id=this.adminMovieForm.controls['theatre'].value;
    //movie.theatre=theatre;

    alert("fn MODIFY " +JSON.stringify(movie));
    this.ms.modifyMovie(movie).subscribe(data=>console.log(data));

/*     alert("modify theatre id & name " +JSON.stringify(theatre));
    this.ts.modifyTheatre(theatre).subscribe(data=>console.log(data)); */
  }

  fnDelete(){

    var movie=new Movie();
  //  var theatre = new Theatre();

    movie.movieId=this.adminMovieForm.controls['movieId'].value;
    movie.movieName=this.adminMovieForm.controls['movieName'].value;
    movie.theatreId=this.adminMovieForm.controls['theatreId'].value;

    // theatre.id=this.adminMovieForm.controls['theatre'].value;
    // movie.theatre=theatre;

    alert("remove theatre id & name " +JSON.stringify(movie));
    this.ms.removeMovie(movie.movieId).subscribe(data=>console.log(data));

  }

}


