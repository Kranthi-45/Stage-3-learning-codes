package com.example.demo.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.model.Movie;
import com.example.demo.service.MovieService;

@RestController
@CrossOrigin({"*"})
public class MovieController {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	 
	@Autowired
	private MovieService ms;

	@PostMapping("/movie")
	public Movie addMovie(@RequestParam("id") Long id, @RequestParam("name") String name, @RequestParam("releaseDate") String releaseDate, @RequestParam("picture") MultipartFile file ) throws IOException, ParseException
	{
		Movie  movie = new Movie();
		movie.setId(id);
		movie.setName(name);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		movie.setReleaseDate(sdf.parse(releaseDate));
		byte[] picture = file.getBytes();                            // MultipartFile file -> bytes[] & then we are storing it
		movie.setPicture(picture);

		log.info("The picture file has "+picture.length+" bytes");   //  used log to see wheather file is coverted to bytes are not
		return ms.create(movie);
	}

	@GetMapping("/movie")
	public List<Movie> getAllMovies()
	{
		return ms.read();
	}

	@GetMapping("/movie/{id}")
	public Movie findMovieById(@PathVariable("id") Long id)
	{
		return ms.read(id);
	}
	@PutMapping("/movie")
	public Movie modifyMovie(@RequestParam("id") Long id, @RequestParam("name") String name, @RequestParam("releaseDate") String releaseDate, @RequestParam("picture") MultipartFile file ) throws IOException, ParseException
	{
		Movie  movie = new Movie();
		movie.setId(id);
		movie.setName(name);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		movie.setReleaseDate(sdf.parse(releaseDate));
		byte[] picture = file.getBytes();                 // MultipartFile file -> bytes[] & then we are storing it
		movie.setPicture(picture);

		return ms.update(movie);
	}

	@DeleteMapping("/movie/{id}")
	public void removeMovie(@PathVariable("id") Long id) {
		ms.delete(id);
	}
}
