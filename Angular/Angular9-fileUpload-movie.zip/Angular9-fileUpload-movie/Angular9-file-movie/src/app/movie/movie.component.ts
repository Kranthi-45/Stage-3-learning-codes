import { Component, DoCheck, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit, OnChanges, DoCheck {

  movieForm:any;
  file : any;
  movies:any;
  constructor(private fb: FormBuilder, private ms: MovieService) { 
    this.movieForm=this.fb.group({
      id:[''],
      name:[''],
      releaseDate:[''],
      picture:['']
    });
  }
  ngOnChanges(changes: SimpleChanges): void {
      
  }                                                                          // not used 
  ngDoCheck(): void {
  
  }                                                                          // not used 

  ngOnInit(): void {
    this.ms.getAllMovies().subscribe(data=>this.movies=data);                 // for displaying table of records on webpage
  }

  fnChange(event:any)
  {
    this.file=event.target.files[0];
    console.log(this.file.name);
    console.log(this.file.size);
  }

  fnAdd()
  {
    var fd=new FormData();                                                      // we will append each data in formdata whenever user enter details, At last we supply formdata obj BY calling service method
    // alert(this.foodForm.controls['expiryDate'].value);
    fd.append("id",this.movieForm.controls['id'].value);
    fd.append("name",this.movieForm.controls['name'].value);
    fd.append("releaseDate",this.movieForm.controls['releaseDate'].value);
    fd.append("picture",this.file,this.file.name);

    this.ms.addMovie(fd).subscribe(data=>console.log(data));                     // entered data in html form will store in database by calling " Movie servie " method
    alert("Form details submitted")
  }
 

}
