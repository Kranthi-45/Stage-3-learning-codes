import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  url:string='http://localhost:8080/movie';
  constructor(private http:HttpClient) { }

  getAllMovies()
  {
    return this.http.get(this.url);
  }
  findMovieById(id:any)
  {
    return this.http.get(this.url+"/"+id);
  }
  addMovie(movie:any)                           //this is not object of movie. this is object of form data
  {
    return this.http.post(this.url,movie);
  }
  modifyMovie(movie:any)
  {
    return this.http.put(this.url,movie);
  }
  removeMovie(id:any)
  {
    return this.http.delete(this.url+"/"+id);
  }
}
