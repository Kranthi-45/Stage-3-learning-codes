export class Products {                                                                  // 3rd => create  class ( use fake rest api :https://api.instantwebtools.net/v1/airlines ) and declare variables
    id:number=1;                                                                         // 4th => create (products component) using command "ng g c products &  import "ReactiveFormsModule" in (app.module.ts)"
    title:string="Fjallraven - Foldsack No. 1 Backpack, Fits 15 Laptops";                // 5th => write "productForm:any" in (products.component.ts) & pass FormBuilder as constructor param = 
    price:number=109.95;                                                                 //     ProductForm (is like "@modelAttribute" in spring) that links this (product.ts) and (products.html)
    description:string="Your perfect pack for everyday use and walks in the forest. Stash your laptop (up to 15 inches) in the padded sleeve, your everyday",
    category:string="men's clothing";
    image:string=""

}
