import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {                   // 5th => write  "productsForm:any" & FormBuilder in typescript
  productsForm:any;                                                  // like @modelAttribute links boths products.ts and products.html

  constructor(private fb: FormBuilder )                              // FormBuilder next 6th => create Products Form in (products.component.html)
  { 
    this.productsForm=fb.group({
      id:[''],
      title:[''],
      price:[''],
      description:[''],
      category:[''],
      image:['']
    });
  }

  ngOnInit(): void {
  }

}
