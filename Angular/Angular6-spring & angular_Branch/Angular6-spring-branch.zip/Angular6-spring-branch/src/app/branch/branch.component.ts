import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { BranchService } from '../branch.service';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.css']
})
export class BranchComponent implements OnInit {
  branchForm:any;
  branches:any;

  constructor(private fb:FormBuilder, private bs:BranchService) {
    this.branchForm=this.fb.group({
      bid:[],
      bname:[],
      bcity:[]
    })
   }

  ngOnInit(): void {
    //this.bs.getAllBranches().subscribe((data)=>console.log(data));
    this.bs.getAllBranches().subscribe((data)=>{
     console.log(data);
     this.branches=data;                                       // we are getting records via (data) varible and received data storing in branches  [] array to display on page
    });
  }
  fnSelect(bid:any)
  {
    this.bs.findBranchById(bid).subscribe((data)=>{
      this.branchForm.patchValue(data);                        // patchValue: (patch the values into form)when we select button it will add that row records into form text fields to edit
    });
  }

  fnAdd()
  {
    var branch=this.branchForm.value;
    this.bs.addBranch(branch).subscribe(data=>console.log(data));      // Subscribe : ? we have to subscribe the observable objects to display add, modify it
  }

  fnModify()
  {
    var branch=this.branchForm.value;
    this.bs.modifyBranch(branch).subscribe(data=>console.log(data));
  }

  fnDelete()
  {
    var branch=this.branchForm.value;
    this.bs.deleteBranch(branch).subscribe(data=>console.log(data));
  }

}
