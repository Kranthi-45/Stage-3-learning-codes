import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { AirlineComponent } from './airline/airline.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { HttpClientModule } from '@angular/common/http';                // 9.1 => write this import {}(with empty braces) then write "httpClientModule" below in "imports:" 

@NgModule({
  declarations: [
    AppComponent,
    AirlineComponent
  ],
  imports: [
    BrowserModule,                                       
    FormsModule,                                                        // for using ngModel import FormsModule here  (ngModel for two way binding : html <=> typescript)              
    ReactiveFormsModule,                                                
    HttpClientModule                                                    // 9.1.1 =>  import "HttpClientModule" here to use fake REST API's urls to upd,mod,del 
  ],
  providers: [],                                                        // 10 => Create Service class using "ng g s airline" (external world access should be done by 'service' class) & go to (airline.service.ts)
  bootstrap: [AppComponent]
})
export class AppModule { }
