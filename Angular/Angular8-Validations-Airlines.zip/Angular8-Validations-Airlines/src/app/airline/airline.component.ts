import { Component, OnInit } from '@angular/core';
import { AbstractControl, ControlContainer, FormBuilder, Validators } from '@angular/forms';
import { AirlineService } from '../airline.service';

@Component({
  selector: 'app-airline',
  templateUrl: './airline.component.html',
  styleUrls: ['./airline.component.css']
})
export class AirlineComponent implements OnInit {
  airlineForm:any;                                                                                        // 5th => write  "airlineForm:any" & FormBuilder in typescript
  airlines:any;                                                                                           // var used in below methods for assigning result                                                                                 
  constructor(private fb: FormBuilder, private as:AirlineService)                                         // 10th => inject service class here in constructor and call all service methods from here
  {                                                                                                       // like @modelAttribute links boths airline.ts and airline.html
    this.airlineForm=fb.group({                                                                           // FormBuilder next 6th => create Airline Form in (airline.component.html)
      
       id:['', [Validators.required, Validators.min(1000)]],
      // name:['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
       name:['', [Validators.required]],
       country:[''],
       logo:[''],
       slogan:[''],
       head_quaters:[''],
       website:[''],
       established:['', [Validators.required, this.validateYear]]
    });

  }
  
  ngOnInit(): void {                                                                                // 10.1 =>  write(call) readAllAirlines() in OnInit() to display first directly when we load form page
   
   // this.as.readAllAirlines().subscribe((data)=>{console.log(data)});                             // 11.1 => for checking by using inspect(console) on web wheather the values are coming,loading or not below line to display records direclty on webpage in table
    this.as.readAllAirlines().subscribe((data)=>{this.airlines=data});                              // 11th => create table in (airline.component.html) to display records  -> (data) = is retrived from central db (fake api) we assigning to "airlines" variable
  }

  validateYear(control: AbstractControl): {[key: string]: any} | null {
     if(control.value && (control.value<1900 || control.value>2021)){
       return {'yearInvalid': true};
     }
     return null;
  }

  fnSelect(id:number)
  {
    this.as.findAirlineById(id).subscribe((data)=>{
      // i am going to patch this object into the FORM                           
      this.airlineForm.patchValue(data);
    });
  }

  fnAdd()
  {
     // alert(this.airlineForm.valid);
     if(!this.airlineForm.valid)
     {
       alert('validation failed');
       return;
     }
     // the entire form should be rep as an object and send that object to the rest API
     var airline=this.airlineForm.value;
     console.log("sending new object:");
     console.log(JSON.stringify(airline));
     this.as.addAirline(airline).subscribe(data=>console.log(data));

  }



 /*  fnSelect(id:number){
    alert(id);                    // this fun() is called from  (airline.component.html) using (click)="fnSelect(a.id)"
        or
    this.as.findAirlineById(id).subscribe((data)=>{alert(JSON.stringify(data))});   // testing overall obj in alert
  }  */

}
