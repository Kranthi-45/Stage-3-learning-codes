export class Airline {
    id:number=8;                                                // 3rd => create airline class ( use fake rest api :https://fakestoreapi.com/docs ) and declare variables
    name:string="Thai Airways";                                 // 4th => create (airline component) using command "ng g c airline" & open (app.component.html) see -> templateUrl: './app.component.html'  is imported automatically  because of new component creation,
    country:string="Thailand";                                  //     import "ReactiveFormsModule" in (app.module.ts)"
    logo:string="";                                             // 5th => write "airlineForm:any" in (airline.component.ts) & pass FormBuilder as constructor param =    
    slogan:string="";                                           //    -airlineForm (is like "@modelAttribute" in spring) that links this (product.ts) and (products.html)
    head_quaters:string="";
    website:string="";
    established:number=2021;
}
