export class MyUser {
    
    username:string | undefined;
    password:string | undefined;
}
