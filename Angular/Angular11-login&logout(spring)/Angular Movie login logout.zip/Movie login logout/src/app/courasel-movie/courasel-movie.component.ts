import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-courasel-movie',
  templateUrl: './courasel-movie.component.html',
  styleUrls: ['./courasel-movie.component.css']
})
export class CouraselMovieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
