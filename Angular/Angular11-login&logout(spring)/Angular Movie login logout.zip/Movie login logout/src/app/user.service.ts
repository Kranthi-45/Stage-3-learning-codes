import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  url:string='http://localhost:8081/user';
  
  constructor(private http:HttpClient) { }

  dummy()
  {
    return this.http.get("http://localhost:8081");
  }

  getAllUsers(){
    return this.http.get(this.url);
  }

  login(username:string, password:string)
  {
    return this.http.get(this.url+"/"+username+"/"+password);
  }

  signup(myuser:any)
  {
    return this.http.post(this.url,myuser);
  }

  loginStatus()
  {
    // alert('login status of service')
    var user=localStorage.getItem("user");
  
    const myObservable=new Observable(observer=>{
      setTimeout(()=>{
         
        observer.next(user);
      },100);
    });
    return myObservable;
  }
}
