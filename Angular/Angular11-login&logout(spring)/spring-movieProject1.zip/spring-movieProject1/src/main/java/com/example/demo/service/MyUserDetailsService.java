package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.MyUser;
import com.example.demo.repository.UserRepository;


@Service
public class MyUserDetailsService {

	@Autowired
	private UserRepository ur;
	
	public MyUser create(MyUser user) {
		return ur.save(user);
	}
	public List<MyUser> read() {
		return ur.findAll();
	}
	public MyUser read(String username) {
		return ur.findById(username).get();
	}
	public MyUser update(MyUser user) {
		return ur.save(user);
	}
	public void delete(String username) {
		ur.delete(read(username));
	}
	
}
