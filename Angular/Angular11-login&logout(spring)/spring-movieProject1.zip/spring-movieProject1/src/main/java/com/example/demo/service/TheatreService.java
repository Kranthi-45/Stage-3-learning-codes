package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Theatre;
import com.example.demo.repository.TheatreRepository;

@Service
public class TheatreService {

	@Autowired
	private TheatreRepository tr;
	
	public Theatre create(Theatre theatre) {
		return tr.save(theatre);
	}
	public List<Theatre> read() {
		return tr.findAll();
	}
	public Theatre read(Long id) {
		return tr.findById(id).get();
	}
	public Theatre update(Theatre theatre) {
		return tr.save(theatre);
	}
	public void delete(Long id) {
		tr.delete(read(id));
	}
}
