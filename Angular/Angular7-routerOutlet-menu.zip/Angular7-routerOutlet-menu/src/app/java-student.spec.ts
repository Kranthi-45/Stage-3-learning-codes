import { JavaStudent } from './java-student';

describe('JavaStudent', () => {
  it('should create an instance', () => {
    expect(new JavaStudent()).toBeTruthy();
  });
});
