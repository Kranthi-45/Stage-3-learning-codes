export class Branch 
{
    bid:string='B00001';
	bname:string='New branch';
	bcity:string='Kolkata';
}
