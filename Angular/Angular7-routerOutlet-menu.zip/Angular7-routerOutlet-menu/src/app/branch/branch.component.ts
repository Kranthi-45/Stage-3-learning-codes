import { Component, OnInit } from '@angular/core';
import { Branch } from '../branch';

@Component({
  selector: 'app-branch',
  // template:`<b><i>Not coming Branch
  //  works now</i></b>`,
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.css']
})
export class BranchComponent implements OnInit 
{
  bid:string="B00002";
  bname:string="Park circus avenue branch";
  bcity:string="Kolkata";

  constructor() { }

  ngOnInit(): void {
  }

  fnAdd()
  {
    // alert("hello world");
    // alert(this.bid+" : "+this.bname+" : "+this.bcity);
    var branch:Branch=new Branch();
    branch.bid=this.bid;
    branch.bname=this.bname;
    branch.bcity=this.bcity;
    console.log(branch);
    alert(JSON.stringify(branch));
  }
}
