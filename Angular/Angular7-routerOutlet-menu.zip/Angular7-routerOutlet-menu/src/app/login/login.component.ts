import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  @Input() title:string="Something";

  @Output() loginEvent =new EventEmitter<string>();
  username:string='';
  password:string='';
  constructor() { }

  ngOnInit(): void {
  }

  fnLogin()
  {
    this.loginEvent.emit(this.username+":"+this.password);    
  }
}
