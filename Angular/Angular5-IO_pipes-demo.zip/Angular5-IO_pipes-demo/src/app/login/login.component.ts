
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  today:Date=new Date();
  salary:number=123456.7890;
  name:string='this is a sentence'
  
                                                              // dynamically we give input on web page  see in (login.component.html) we use interpolation to use this value there like dynamcally
  @Input() title:string="something";                          // @Input makes: parent component gives input to the child)
 
  @Output() loginEvent= new EventEmitter<string>();           // @Output : to emit output by parent instead child 

  username:string='';                                         // declared for two way binding => whenever values are given in browser values comes to this .ts page and stores thess values and print alert or used for other purpose
  password:string='';
 
  constructor() { }

  ngOnInit(): void {
  }

  fnLogin(){                                                     // for (click) event
  
    // alert(this.username+" : "+this.password);                 // defaut child event output      
    //this.loginEvent.emit(this.username+" : "+ this.password);  // emit output to parent to display as parent wishes (@Output) this go to (app.component.ts) file & execute fnLogin() event of parent.
    this.loginEvent.emit(this.username+":"+ this.password); 
    alert("done");
  }
}
