import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'headingLen'
})
export class HeadingLenPipe implements PipeTransform {

  transform(value: any, ...args: unknown[]): unknown {
    return value.length;
  }

}
