import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular-IO';

  fnLogin(data:any)
  {
    alert("parent has received data" + data);
    var arr=data.split(":");
    alert(arr[0])
    alert(arr[1])
  }
}
