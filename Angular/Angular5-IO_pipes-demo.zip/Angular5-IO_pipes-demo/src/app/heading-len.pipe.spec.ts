import { HeadingLenPipe } from './heading-len.pipe';

describe('HeadingLenPipe', () => {
  it('create an instance', () => {
    const pipe = new HeadingLenPipe();
    expect(pipe).toBeTruthy();
  });
});
