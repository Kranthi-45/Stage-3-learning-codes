package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeptEmpDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeptEmpDemoApplication.class, args);
		System.out.println("Hello world");
	}

}
