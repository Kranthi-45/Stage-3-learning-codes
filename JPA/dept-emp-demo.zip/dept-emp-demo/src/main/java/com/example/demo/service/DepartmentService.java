package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Department;
import com.example.demo.repository.DepartmentRepository;

@Service
public class DepartmentService {
	@Autowired
	private DepartmentRepository dr;
	public Department create(Department department) {
		return dr.save(department);
	}
	public List<Department> read() {
		return dr.findAll();
	}
	public Department read(Long id) {
		return dr.findById(id).get();
	}
	public Department update(Department department) {
		return dr.save(department);
	}
	public void delete(Long id) {
		dr.delete(read(id));
	}

}
