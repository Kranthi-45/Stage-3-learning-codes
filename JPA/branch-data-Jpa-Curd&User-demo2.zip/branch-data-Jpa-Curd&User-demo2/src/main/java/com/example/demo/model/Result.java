package com.example.demo.model;

public class Result {
 private String bname;
 private String bcity;
}
