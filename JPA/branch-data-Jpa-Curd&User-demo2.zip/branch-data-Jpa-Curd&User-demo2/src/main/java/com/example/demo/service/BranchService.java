package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Branch;
import com.example.demo.repository.BranchRepository;

@RestController
public class BranchService {

	@Autowired
	private BranchRepository br;
	
	//----------------------------------------------------------Crud Operations(basic) ------------------------------	
	
	
	public Branch create(@RequestBody Branch branch) {
		return br.save(branch);
	}
	public List<Branch> read() {
		return br.findAll();
	}
	public Branch read(@PathVariable("bid") String bid) {
		return br.findById(bid).get();
	}
	public Branch update(@RequestBody Branch branch) {
		return br.save(branch);
	}
	public void delete(@RequestBody Branch branch) {
		br.delete(branch);
	}
	
	//---------------------------------------------------USER DEfined DDL operations-------------------------------	

	public List<Branch> findBranchByCity(String bcity){
		
		return br.findBranchByCity(bcity);
	}
//	public List<Object> getDetails(@Param("bid") String bid);
	
	public List<Object> getDetails(String bid)
	{
		return br.getDetails(bid);
	}
	
	public List<Branch> findBranchByLetter(String bname)
	{
		return br.findBranchByLetter(bname);
	}
}
