 Project : Only  Basic curd operations (create/update/delete/get)


Spring data JPA (Java Persistence API):
__________________________________________

What we do in JDBC?
       INSERT INTO branch VALUES(?,?,?)
       UPDATE branch SET bname=?, bcity=?, where bid=?
       DELETE branch WHERE bid=?
       SELECT * FROM branch

# Same code done in many projects, so why not we create framework that will take care of these tasks

# But every component should be independent. in one layer, we have database related code. in another layer we are not supposed to have.
	because, the roles of programmers are separated. One team will be doing DAO code
	another team will create UI	(web / mobile/ windows/ console)
	so UI team should write java code independent of any database.

# The above basic queries will not be coded when we use frameworks like Hibernate, Spring Data JPA

# While trying to create f/w, what are the things to be considered?
    -Table name?
    -if the table has 5 columns ? then there are 5 question marks 
 	
# If f/w is going to take care of these operations, then f/w should understand our Entity class first.
	Because, sometimes, 
	
	Entity class "Employee"     ->  but table name can be "EMP"
	Entity class can be "User".	->	but in db "user" is a keyword, table name can be "USER_MASTER"

            Table name      vs         Entity class name
            columns         vs         properties
            primary key to be defined
       
# Entity Class : the class that is mapped to a table is a entity classes called ORM
                 ORM ------------ Object Relational Mapping             
                 
       Mapping : there are 2 ways we can do ORM
                 1) XML mapping
                 2) Annotations         

JPA evolved 
   -> JPA is a concept	
	     1) EJB        -  First implemented JPA concept ( we create "persistence.xml")
	     2) Hibernate  -  this f/w evolved. This simplified JPA concept
	     3) JPA        -  Again JPA f/w evolved to implement jpa concept..not very popular
	     4) Spring     -  Robust (it is implemented with below )
	                           
	                            i) jdbctemplate
	                           ii) hibernate template
	                          iii) hibernate dao support
	                           iv) entity manager
	     
	    5) Spring Boot -       
	                            i) crud repository
	                           ii) jpa repository
	                          iii) PagingAndSortingRespository   
	                          
	
In this we use latest 	"Spring Boot Jpa" : 
----------------------------------------
 -> Spring Boot  there is a starter dependency 
                		spring data jpa

     	ex: 	i) CUSTOMER
	     	   ii) PRODUCT
	
	  Entities become 
		  Tables (in the database)
		  Classes (in our java programs)
    	  The relationship between customer and product is Many to Many Hence the relationship also becomes an entity
    
 -> Spring data jpa fw will automatically put _ wherever a new word is found
		companyName
		"N" is captial in java, so spring data understands that a new word begins with N
		COMPANY_NAME
	
 ->	 SpringBoot jpa repository uses "Hibernate only"
 
 Hibernate: (using Mapping file xml)
 
        hibernate.cfg.xml  - url,driver,username,password, dialect(mysql,oracle = dialect tells which sql statments it should write ?)
        
        entity1.hbm.xml    - 
        entity2.hbm.xml    -  classname vs tablename   , property vs column     
              
     Instead of using MAPPING in xml file, we use annotations in  modern programming

 Hibernate:(using Annotations)
   
      @Entity             -  this class (mapped to a table in db) by default table name is same as classname
      @Table		      -  to specify the table name when it is same or different from entity class
      @Table(name="EMP")  -  table name is "EMP" mapped to entity class "Employee"
      @Id			      -  primary key
	  @GeneratedValue	  -  used to specify auto generate strategy (APPLIED ONLY FOR NUMERIC DATA TYPES)
	        @GeneratedValue(strategy=GenerationType.AUTO)
	                                     AUTO
	                                     SEQUENCE
	                                     IDENTITY
	  @Column	          -  is used when property name is different form column name
       
  LOT OF ANNOTATIONS ARE USED:
           @Lob
           @NotNull
           @Transient
                
In ideal Spring Boot Application (Project) contains 
      Entity Class
      Repository Interface  - for every entity
      Service Class
      Controller Class

   spring.jpa.properties.hibernate.dialect  --> choose which sql statments to execute mysql ? oracle ?
   spring.jpa.hibernate.ddl-auto=update     --> DDL (CREATE, ALTER, DROP, TRUNCATE)
                         create-drop           |      if table not found it will
                         create                |             CREATE
                         drop                  |      if tabel vs class does not match columns
                         update                |            Alter



  spring.jpa.show-sql=true                  --> shows sql commands/statements in console


but why?
	in your project, i saw "select * from Employee"
		this query will result in multiple records of Employees (0 more records)
	how will you store the result in java program?
		List<Employee>

		you might think about ResultSet???????	
		while(rs.next())
-------------------------------------------------------------------------Steps to do project ------------------------------------------------------
This projects is for both basic curd operations and user defined operation

class Branch
{

	private String bid;
	private String bname;
	private String bcity;	
}

1) Spring Boot application
	i) Spring Tool Suite?
	ii) Eclipse?

2) we create a spring boot starter project		
	spring web	(because i want to see output in browser or postman)
	data jpa 	(i will add dependency)

3) set up the connection properties
	Application.properties
	
4) Create "JPA repository interface" is a super interface, which we are going to inherit
                               -- public interface BranchRepository extends JpaRepository<Branch, String> -- (< obj, primarykey data type>)

5) Creat "Entity Class(Model)" -- Use @Entity, @ID..etc for ORM (creating model class Branch and table branch in db at a time)

6) Create "Controller Class"   -- for URL mapping and redirect to specific method in Service Class(When we give url localhost in browser/postman first come to controller only)
                                      @GetMapping     -- only for find(),findAll(), userdefined retrive operations
                                      @PostMapping    -- save (create)
                                      @PutMapping     --  save (update) 
                                      @DeleteMapping  -- delete(remove)
                                      
7) Create "Service Class"      -- for operations like update,delete,save,create inbuilt methods (DML to be happen automatocally without sql queries) 
                                       br.save(obj)           -- create & update
                                       br.findAll()           -- read all 
                                       br.findById(Obj).get() -- read by id
                                       br.delete(obj)         -- remove branch  
                                 
                                  above are basic/curd operations we can also define user defined operations like below
                                   ex:  
                                        br.findBranchByCity(bcity);
                                        br.findBranchByLetter(bname);
                                   

8) Run the Program using SpringBoot Application

9) See output in Browser or POSTMAN

           IN Browser(only GET/select urls are only)                  : localhost:8080/branch/  (this urls are defined in controller see there and enter in adresss bar in browser/postman)
           IN POSTMAN(GET/PUT/POST/DELETE/UPDATE  all urls...etc)     : localhost:8080/branch/ 

  IMP POINTS:
  -----------
     if the entity class name is "Branch"        -- it wll create table as "branch"
                               "KranthiBranch" -- kranthi_Branch
     to avoid above we write below lines in Application.properties
               
         spring.jpa.hibernate.naming.physical-strategy=org.hibernate.boot.model.naming.PhysicalNamingStrategyStandardImpl
                               

 