package com.example.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Details;
import com.example.demo.entity.Engineer;
import com.example.demo.service.EngineerService;

@RestController
public class EngineerController {

	@Autowired
	private EngineerService es;
	@GetMapping("/")
	public List<Engineer> read()
	{
		return es.read();
	}
	
	@GetMapping("/{engineerId}")
	public Engineer read(@PathVariable("engineerId")Long engineerId)
	{
		return es.read(engineerId);
	}
	
	@GetMapping("/city/{city}")
	public List<Engineer> findEngineerByCity(@PathVariable("city")String city)
	{
		return  es.findEngineerByCity(city);
	}
	
	@GetMapping("/detail/{eid}")
	public Details findDetail(@PathVariable("eid")Long engineerId)
	{
		return es.getDetail(engineerId);
	}
	
	@PostMapping("/")
	public Engineer create(@RequestBody Engineer engineer)
	{
		return es.create(engineer);
	}
	
	@PutMapping("/")
	public Engineer update(@RequestBody Engineer engineer)
	{
		return es.update(engineer);
	}
	
	@DeleteMapping("/{engineerId}")
	public void delete(@PathVariable("engineerId") Long engineerId)
	{
		es.delete(engineerId);
	}
}
