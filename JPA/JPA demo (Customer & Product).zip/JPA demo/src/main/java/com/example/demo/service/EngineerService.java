package com.example.demo.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Details;
import com.example.demo.entity.Engineer;
import com.example.demo.repository.EngineerRepository;

@Component
public class EngineerService {

	@Autowired
	private EngineerRepository erepo;
	public Engineer create(Engineer engineer)
	{
		return erepo.save(engineer);
	}
	public List<Engineer> read()
	{
		return erepo.findAll();
	}
	public Engineer read(Long engineerId)
	{
		return erepo.findById(engineerId).get();
	}
	public Engineer update(Engineer engineer)
	{
		return create(engineer);
	}
	public void delete(Long engineerId)
	{
		
		erepo.delete(read(engineerId));
	}
	public List<Engineer> findEngineerByCity(String city)
	{
		return erepo.findEngineersByCity(city);
	}
	
	public Details getDetail(Long engineerId)
	{
		return erepo.findDetails(engineerId);
				
	}
}
